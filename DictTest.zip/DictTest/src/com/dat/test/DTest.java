package com.dat.test;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;

public class DTest implements ActionListener {

	private static JLabel checked = new JLabel("Ready...");
	private static JLabel tempted = new JLabel("Ready...");
	private static JTextField user = new JTextField(20);
	private static DictRead ob = new DictRead();
	private static String[] Dict;
	private static List<String> tried =new ArrayList<String>(); 
	private static String word;

	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		JLabel title = new JLabel("Dictionary Test");
		JLabel label = new JLabel("Enter Word Here:");

		frame.setSize(350, 350);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		frame.add(panel);

		panel.setLayout(null);

		title.setBounds(30, 40, 200, 30);
		title.setFont(new Font("Courier New", Font.BOLD, 18));
		label.setBounds(30, 100, 100, 25);
		label.setFont(new Font("Times New Roman", Font.PLAIN, 14));

		panel.add(title);
		panel.add(label);

		user.setBounds(140, 100, 165, 25);
		user.setFont(new Font("Arial", Font.BOLD, 12));
		panel.add(user);

		JButton ok = new JButton("Check");
		ok.setBounds(140, 160, 100, 30);
		ok.addActionListener(new DTest());
		panel.add(ok);

		checked.setBounds(30, 200, 215, 25);
		checked.setFont(new Font("Times New Roman", Font.BOLD, 14));
		panel.add(checked);
		
		tempted.setBounds(30, 250, 215, 25);
		tempted.setFont(new Font("Times New Roman", Font.BOLD, 14));
		panel.add(tempted);

		/////////////////////////////////////////////////////////////////////
		Dict = ob.arrayCreate();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		word = user.getText();
		if (tried.contains(word) == true) {
			tempted.setText("You've already tried this word");
		}
		else {
			tempted.setText("You haven't used this word before");
			tried.add(word);
		}
		
		
		boolean there = ob.checkInDict(Dict, word);
		System.out.println(there);
		if (there == true) {
			checked.setText("The word " + "'" + word + "'" + " exists");
		} else {
			checked.setText("The word " + "'" + word + "'" + " does not exist");
		}

	}

}
